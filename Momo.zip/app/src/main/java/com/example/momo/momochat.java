package com.example.momo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.widget.ListView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class momochat extends AppCompatActivity {

    ListView m_ListView;
    //CustomAdapter m_Adapter;  //CustomAdapter 에러로 인한 주석처리

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.momo_chat);

        setTitle("모모랑 밥먹자☆");

        /*  CustomAdapter 에러로 인한 주석처리
        //커스텀 어댑터 생성
        m_Adapter = new CustomAdapter();

        //xml에서 추가한 ListView 연결
        m_ListView = (ListView)findViewById(R.id.listView1);

        //ListView에 어댑터 연결
        m_ListView.setAdapter(m_Adapter);

        m_Adapter.add("모모", 1);
        */

        StrictMode.enableDefaults();

        TextView status1 = (TextView) findViewById(R.id.result); //파싱된 결과확인!

        // String API_KEY =null, type=null, API_URL=null, START_INDEX=null, END_INDEX=null, IRDNT_NM=null, RECIPE_ID=null;

        boolean inROW_NUM = false, inRESIPE_ID = false, inIRDNT_SN = false, inIRDNT_NM = false, inIRDNT_CPCTY = false;
        boolean inIRDNT_TY_CODE = false, inIRDENT_TY_NM = false;
        boolean inStatUpdateDatetime = false;

        String ROW_NUM = null, RERCIPE_ID = null, IRDNT_NM = null, IRDNT_SN = null, IRDNT_CPCTY = null, IRDNT_TY_CODE = null, IRDENT_TY_NM = null;

        String statUpdateDatetime = null;


        try {
            URL url = new URL("http://211.237.50.150:7080/openapi/e0dc5094e4aee7fed72470e0f20670c4a8bce5139b5adacc0795f941049d98f1/xml/Grid_20150827000000000227_1/1/1000"); //검색 URL부분
            InputStream is = url.openStream();

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new InputStreamReader(is, "UTF-8"));
            int eventType = parser.getEventType();

            String result = "";
            while(eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        String startTag = parser.getName();
                        switch (startTag) {
                            case "row":
                                // start of record
                                break;
                            case "ROW_NUM":
                                result += "ROW_NUM: " + parser.nextText();
                                break;
                            case "RECIPE_ID":
                                result += ", RECIPE_ID: " + parser.nextText();
                                break;
                            case "IRDNT_TY_NM":
                                result += ", IRDNT_TY_NM: " + parser.nextText();
                                break;
                            case "IRDNT_TY_CODE":
                                result += ", IRDNT_TY_CODE: " + parser.nextText();
                                break;
                            case "IRDNT_SN":
                                result += ", IRDNT_SN: " + parser.nextText();
                                break;
                            case "IRDNT_NM":
                                result += ", IRDNT_NM: " + parser.nextText();
                                break;
                            case "IRDNT_CPCTY":
                                result += ", IRDNT_CPCTY: " + parser.nextText();
                                break;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        String endTag = parser.getName();
                        if(endTag.equals("row")) {
                            // end of record
                            result += "\n";
                            status1.setText(result);
                        }
                        break;
                }
                eventType = parser.next();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}


package com.example.momo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnmono, btnset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("모모");

        Button btnmomo = (Button) findViewById(R.id.btnMomo);
        Button btnset = (Button) findViewById(R.id.btnSet);

        Intent intent = getIntent();
        String potal = intent.getStringExtra("POTAL");

        btnset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, set_up.class);
                intent.putExtra("POTAL", "모모");
                startActivity(intent);
            }
        });

        btnmomo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, momochat.class);
                intent.putExtra("POTAL", "모모");
                startActivity(intent);
            }
        });

    }
}

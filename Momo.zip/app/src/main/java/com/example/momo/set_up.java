package com.example.momo;

        import androidx.appcompat.app.AppCompatActivity;

        import android.app.AlarmManager;
        import android.app.PendingIntent;
        import android.content.ComponentName;
        import android.content.Context;
        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.content.pm.PackageManager;
        import android.os.Build;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.CompoundButton;
        import android.widget.Switch;
        import android.widget.TimePicker;
        import android.widget.Toast;

        import java.text.SimpleDateFormat;
        import java.util.Calendar;
        import java.util.Date;
        import java.util.GregorianCalendar;
        import java.util.Locale;

public class set_up extends AppCompatActivity {
    Switch switch1;
    Button btnSetup;
    CheckBox chkmon, chktues, chkwednes, chkthurs, chkfri, chksatur, chksun, chkfrist, chksecond, chkthird;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_up);

        setTitle("알람 설정");

        Switch switch1 = (Switch) findViewById(R.id.switch1);

        /* 스위치 시도
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    //On
                }
                else {
                    //Off
                }
            }
        }); */


        //첫번째 식사 체크박스
        chkfrist = (CheckBox) findViewById(R.id.chkFirst);

        chkfrist.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isCheked) {
                if(chkfrist.isChecked() == true) { //체크박스가 선택되었을 때  알람 실행

                    final TimePicker picker=(TimePicker)findViewById(R.id.timeFrist);

                    // 앞서 설정한 값으로 보여주기
                    // 없으면 디폴트 값은 현재시간
                    SharedPreferences sharedPreferences = getSharedPreferences("daily alarm", MODE_PRIVATE);
                    long millis = sharedPreferences.getLong("nextNotifyTime", Calendar.getInstance().getTimeInMillis());

                    Calendar nextNotifyTime = new GregorianCalendar();
                    nextNotifyTime.setTimeInMillis(millis);

                    Date nextDate = nextNotifyTime.getTime();
                    String date_text = new SimpleDateFormat("yyyy년 MM월 dd일 EE요일 a hh시 mm분 ", Locale.getDefault()).format(nextDate);
                    //Toast.makeText(getApplicationContext(),"[처음 실행시] 다음 알람은 " + date_text + "으로 알람이 설정되었습니다!", Toast.LENGTH_SHORT).show();

                    // 이전 설정값으로 TimePicker 초기화
                    Date currentTime = nextNotifyTime.getTime();
                    SimpleDateFormat HourFormat = new SimpleDateFormat("kk", Locale.getDefault());
                    SimpleDateFormat MinuteFormat = new SimpleDateFormat("mm", Locale.getDefault());

                    int pre_hour = Integer.parseInt(HourFormat.format(currentTime));
                    int pre_minute = Integer.parseInt(MinuteFormat.format(currentTime));

                    if (Build.VERSION.SDK_INT >= 23 ){
                        picker.setHour(pre_hour);
                        picker.setMinute(pre_minute);
                    } else{
                        picker.setCurrentHour(pre_hour);
                        picker.setCurrentMinute(pre_minute);
                    }

                    //버튼을 누르면 알람을 설정하기
                    Button button = (Button) findViewById(R.id.btnSetup);
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View arg0) {

                            int hour, hour_24, minute;
                            String am_pm;
                            if (Build.VERSION.SDK_INT >= 23) {
                                hour_24 = picker.getHour();
                                minute = picker.getMinute();
                            } else {
                                hour_24 = picker.getCurrentHour();
                                minute = picker.getCurrentMinute();
                            }
                            if (hour_24 > 12) {
                                am_pm = "PM";
                                hour = hour_24 - 12;
                            } else {
                                hour = hour_24;
                                am_pm = "AM";
                            }


                            // 현재 지정된 시간으로 알람 시간 설정
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTimeInMillis(System.currentTimeMillis());
                            calendar.set(Calendar.HOUR_OF_DAY, hour_24);
                            calendar.set(Calendar.MINUTE, minute);
                            calendar.set(Calendar.SECOND, 0);

                            // 이미 지난 시간을 지정했다면 다음날 같은 시간으로 설정
                            if (calendar.before(Calendar.getInstance())) {
                                calendar.add(Calendar.DATE, 1);
                            }

                            Date currentDateTime = calendar.getTime();
                            String date_text = new SimpleDateFormat("yyyy년 MM월 dd일 EE요일 a hh시 mm분 ", Locale.getDefault()).format(currentDateTime);
                            Toast.makeText(getApplicationContext(), date_text + " 모모랑 밥먹어요☆", Toast.LENGTH_SHORT).show();

                            //  Preference에 설정한 값 저장
                            SharedPreferences.Editor editor = getSharedPreferences("daily alarm", MODE_PRIVATE).edit();
                            editor.putLong("nextNotifyTime", (long) calendar.getTimeInMillis());
                            editor.apply();

                            diaryNotification(calendar);
                        }
                    });
                } else { //체크박스를 풀었을 때 알람이 취소되는 코드

                    final TimePicker picker=(TimePicker)findViewById(R.id.timeFrist);

                    // 앞서 설정한 값으로 보여주기
                    // 없으면 디폴트 값은 현재시간
                    SharedPreferences sharedPreferences = getSharedPreferences("daily alarm", MODE_PRIVATE);
                    long millis = sharedPreferences.getLong("nextNotifyTime", Calendar.getInstance().getTimeInMillis());

                    Calendar nextNotifyTime = new GregorianCalendar();
                    nextNotifyTime.setTimeInMillis(millis);


                    // 이전 설정값으로 TimePicker 초기화
                    Date currentTime = nextNotifyTime.getTime();
                    SimpleDateFormat HourFormat = new SimpleDateFormat("kk", Locale.getDefault());
                    SimpleDateFormat MinuteFormat = new SimpleDateFormat("mm", Locale.getDefault());

                    int pre_hour = Integer.parseInt(HourFormat.format(currentTime));
                    int pre_minute = Integer.parseInt(MinuteFormat.format(currentTime));


                    if (Build.VERSION.SDK_INT >= 23 ){
                        picker.setHour(pre_hour);
                        picker.setMinute(pre_minute);
                    } else{
                        picker.setCurrentHour(pre_hour);
                        picker.setCurrentMinute(pre_minute);
                    }

                    //버튼을 누르지 않고도 체크를 푸는 것만으로 취소되도록 함
                    int hour, hour_24, minute;
                    String am_pm;
                    if (Build.VERSION.SDK_INT >= 23 ){
                        hour_24 = picker.getHour();
                        minute = picker.getMinute();
                    } else{
                        hour_24 = picker.getCurrentHour();
                        minute = picker.getCurrentMinute();
                    }

                    if(hour_24 > 12) {
                        am_pm = "PM";
                        hour = hour_24 - 12;
                    } else
                    {
                        hour = hour_24;
                        am_pm="AM";
                    }

                    // 현재 지정된 시간으로 알람 시간 설정
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTimeInMillis(System.currentTimeMillis());
                    calendar.set(Calendar.HOUR_OF_DAY, hour_24);
                    calendar.set(Calendar.MINUTE, minute);
                    calendar.set(Calendar.SECOND, 0);

                    Date currentDateTime = calendar.getTime();
                    String date2_text = new SimpleDateFormat("yyyy년 MM월 dd일 EE요일 a hh시 mm분", Locale.getDefault()).format(currentDateTime);
                    Toast.makeText(getApplicationContext(),date2_text + " 모모는 잠시 자고 있을게요...", Toast.LENGTH_SHORT).show();

                    //  Preference에 설정한 값 저장
                    SharedPreferences.Editor editor = getSharedPreferences("daily alarm", MODE_PRIVATE).edit();
                    editor.putLong("nextNotifyTime", (long)calendar.getTimeInMillis());
                    editor.apply();

                    DeleteNotification(calendar);

                }
            }
        });

    }

    void diaryNotification(Calendar calendar)
    {
//        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
//        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
//        Boolean dailyNotify = sharedPref.getBoolean(SettingsActivity.KEY_PREF_DAILY_NOTIFICATION, true);
//        Boolean dailyNotify = true; // 무조건 알람을 사용

        PackageManager pm = this.getPackageManager();
        ComponentName receiver = new ComponentName(this, alarm_reboot.class);
        Intent alarmIntent = new Intent(this, alarm_Headsup.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);


        // 사용자가 매일 알람을 허용했다면
        boolean dailyNotify = true;
        if (dailyNotify) {
            if (alarmManager != null) {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY, pendingIntent);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                }
            }
            // 부팅 후 실행되는 리시버 사용가능하게 설정
            pm.setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        }
    }

    void DeleteNotification(Calendar calendar)
    {
        PackageManager pm = this.getPackageManager();
        ComponentName receiver = new ComponentName(this, alarm_reboot.class);
        Intent alarmIntent = new Intent(this, alarm_Headsup.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        boolean dailyNotify = true;

        if(dailyNotify) { //알람을 비활성화하는 부분 (Disable Daily Notifications)
            if (PendingIntent.getBroadcast(this, 0, alarmIntent, 0) != null && alarmManager != null) {
                alarmManager.cancel(pendingIntent);
                Toast.makeText(this,"모모는 잠시 자고 있을게요!",Toast.LENGTH_SHORT).show();
            }
            //부팅 후에도  반복되는 알람 비활성화
            pm.setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        }
    }
}
